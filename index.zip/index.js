const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
    let body;
    let statusCode = 200;
    await dynamo
          .put({
            TableName: 'EMPLOYEE',
            Item: {
              EMP_ID: '1',
              name: 'praneeth',
              salary: '20000'
            }
          })
          .promise();
    body = `Put item done`;
  
    return body;
};